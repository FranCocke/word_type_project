from graphic_interface import UI

UI()